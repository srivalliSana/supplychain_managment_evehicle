<?php
require_once(LIB_PATH_INC.DS."config.php");

class MySqli_DB {

    private $con;
    public $query_id;

    function __construct() {
      $this->db_connect();
    }

    /*--------------------------------------------------------------*/
    /* Function for Open database connection
    /*--------------------------------------------------------------*/
    public function db_connect()
    {
        // Connect and select DB in one step
        $this->con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);


        if(!$this->con) {
            die("Database connection failed: " . mysqli_connect_error());
        }
    }

    /*--------------------------------------------------------------*/
    /* Function for Close database connection
    /*--------------------------------------------------------------*/
    public function db_disconnect()
    {
        if(isset($this->con)) {
            mysqli_close($this->con);
            unset($this->con);
        }
    }

    /*--------------------------------------------------------------*/
    /* Function for mysqli query
    /*--------------------------------------------------------------*/
    public function query($sql)
    {
        if (trim($sql) != "") {
            $this->query_id = mysqli_query($this->con, $sql);
        }

        if (!$this->query_id) {
            die("Error on this Query :<pre> " . $sql . "</pre><br>" . mysqli_error($this->con));
        }

        return $this->query_id;
    }

    /*--------------------------------------------------------------*/
    /* Query Helpers
    /*--------------------------------------------------------------*/
    public function fetch_array($statement) { return mysqli_fetch_array($statement); }
    public function fetch_object($statement){ return mysqli_fetch_object($statement); }
    public function fetch_assoc($statement) { return mysqli_fetch_assoc($statement); }
    public function num_rows($statement)   { return mysqli_num_rows($statement); }
    public function insert_id()            { return mysqli_insert_id($this->con); }
    public function affected_rows()        { return mysqli_affected_rows($this->con); }

    /*--------------------------------------------------------------*/
    /* Escape String
    /*--------------------------------------------------------------*/
    public function escape($str){
        return mysqli_real_escape_string($this->con, $str);
    }

    /*--------------------------------------------------------------*/
    /* While Loop Helper
    /*--------------------------------------------------------------*/
    public function while_loop($loop){
        $results = array();
        while ($result = $this->fetch_array($loop)) {
            $results[] = $result;
        }
        return $results;
    }
}

$db = new MySqli_DB();
?>
