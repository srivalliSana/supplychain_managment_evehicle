-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3305
-- Generation Time: May 17, 2024 at 09:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(9, 'Final product'),
(5, 'Machinery');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) UNSIGNED NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `file_name`, `file_type`) VALUES
(1, '900w motor.jpg', 'image/jpeg'),
(2, '1000w motor.jpg', 'image/jpeg'),
(3, 'differential 33.jpg', 'image/jpeg'),
(4, 'front shock obserber with coil spring .jpg', 'image/jpeg'),
(5, 'handel.jpg', 'image/jpeg'),
(6, 'buggy steering - Copy.jpg', 'image/jpeg'),
(7, 'wiper  motor.jpg', 'image/jpeg'),
(8, 'front mud guard.jpg', 'image/jpeg'),
(9, 'handel hold.jpg', 'image/jpeg'),
(10, 'break rod - Copy.jpg', 'image/jpeg'),
(11, 'controller.jpg', 'image/jpeg'),
(12, 'dc to dc converter - Copy - Copy.jpg', 'image/jpeg'),
(13, 'head light .jpg', 'image/jpeg'),
(14, 'wheel hub.jpg', 'image/jpeg'),
(15, '3 wheel front break.jpg', 'image/jpeg'),
(16, 'buzzer.jpg', 'image/jpeg'),
(17, 'hydraulic break master cylinder.jpg', 'image/jpeg'),
(18, 'break rod 13 inch.jpg', 'image/jpeg'),
(19, 'break rod 33 inch - Copy (2).jpg', 'image/jpeg'),
(20, 'key set.jpg', 'image/jpeg'),
(21, 'front indicator.jpg', 'image/jpeg'),
(22, 'gromet small.jpg', 'image/jpeg'),
(23, 'gromet big.jpg', 'image/jpeg'),
(24, 'digital meter.jpg', 'image/jpeg'),
(25, '3W break indicator.jpg', 'image/jpeg'),
(26, 'metal paste.jpg', 'image/jpeg'),
(27, 'buggy front light.jpg', 'image/jpeg'),
(28, 'emergency switchbok.jpg', 'image/jpeg'),
(29, 'wiper blade with arm.jpg', 'image/jpeg'),
(30, 'balancing rod.jpg', 'image/jpeg'),
(31, 'differential oil.jpg', 'image/jpeg'),
(32, 'buggy mirror 100-59.jpg', 'image/jpeg'),
(33, 'passenger mirror 320-2.jpg', 'image/jpeg'),
(34, 'camera set 499-4.jpg', 'image/jpeg'),
(35, 'meter cable 42 inch 150-5.jpg', 'image/jpeg'),
(36, 'roof rubber binding 300-3.jpg', 'image/jpeg'),
(37, 'leaf spring 1300-8.jpg', 'image/jpeg'),
(38, 'Handel t.jpg', 'image/jpeg'),
(39, 'Spray paint.jpg', 'image/jpeg'),
(40, 'powder coating powder .jpg', 'image/jpeg'),
(41, 'powder coating powder 180.jpg', 'image/jpeg'),
(42, 'powder coating powder 350.jpg', 'image/jpeg'),
(43, 'u clamp square plate.jpg', 'image/jpeg'),
(44, 'u clamp.jpg', 'image/jpeg'),
(45, 'fork pipe.jpg', 'image/jpeg'),
(46, 'front glass.jpg', 'image/jpeg'),
(47, 'half roof for holder.jpg', 'image/jpeg'),
(48, 'leaf spring 18.jpg', 'image/jpeg'),
(49, 'leaf spring 19.jpg', 'image/jpeg'),
(50, 'type 3 wheeler.jpg', 'image/jpeg'),
(51, 'tyre(buggy).jpg', 'image/jpeg'),
(52, 'Horn.jpg', 'image/jpeg'),
(53, 'Front axle rod 3 wheeler .jpg', 'image/jpeg'),
(54, 'Battery charger.jpg', 'image/jpeg'),
(55, 'seat from 2 bundles.jpg', 'image/jpeg'),
(56, 'rexine cloth.jpg', 'image/jpeg'),
(57, 'rear break liver.jpg', 'image/jpeg'),
(58, 'chassis 4w.jpg', 'image/jpeg'),
(59, 'chassis 3w passenger.jpg', 'image/jpeg'),
(60, 'front glass support frame.jpg', 'image/jpeg'),
(61, 'demo final product 1.jpg', 'image/jpeg'),
(62, 'demo final  product 2.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `buy_price` decimal(25,2) DEFAULT NULL,
  `sale_price` decimal(25,2) NOT NULL,
  `categorie_id` int(11) UNSIGNED NOT NULL,
  `media_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `buy_price`, `sale_price`, `categorie_id`, `media_id`, `date`) VALUES
(15, '900 W motor', '0', 6500.00, 6900.00, 5, 1, '2024-04-08 08:56:42'),
(16, '1000w motor', '4', 7000.00, 7500.00, 5, 2, '2024-04-08 09:03:27'),
(17, 'Differential 33&#039;', '2', 320.00, 339.00, 5, 3, '2024-04-08 09:18:52'),
(18, 'front shock obserber with coil spring', '13', 2883.00, 3300.00, 5, 0, '2024-04-08 09:31:30'),
(19, 'Handel', '9', 250024.00, 270032.00, 5, 5, '2024-04-08 09:34:37'),
(20, 'Buggy steering', '2', 9000.00, 9500.00, 5, 6, '2024-04-08 09:36:36'),
(21, 'Wiper motor', '34', 1500.00, 1900.00, 5, 7, '2024-04-08 09:37:59'),
(22, 'Front mud guard', '1', 500.00, 540.00, 5, 8, '2024-04-08 09:38:56'),
(23, 'Handel hold', '42', 24.00, 30.00, 5, 9, '2024-04-08 09:40:45'),
(24, 'Break Rod', '2', 540.00, 590.00, 5, 10, '2024-04-08 09:41:35'),
(25, 'Controller', '2', 5000.00, 5400.00, 5, 11, '2024-04-08 09:42:22'),
(26, 'Dc to Dc converter', '7', 7000.00, 7350.00, 5, 12, '2024-04-08 09:43:29'),
(27, 'Head light', '11', 510.00, 575.00, 5, 13, '2024-04-08 09:44:20'),
(28, 'Wheel hub', '3', 7000.00, 7200.00, 5, 14, '2024-04-08 09:45:00'),
(29, '3 wheel front brake', '9', 2400.00, 2900.00, 5, 15, '2024-04-08 09:46:28'),
(30, 'Buzzer', '22', 50.00, 52.00, 5, 16, '2024-04-08 09:47:11'),
(31, 'Hydraulic brake master', '1', 1200.00, 1250.00, 5, 17, '2024-04-08 09:48:11'),
(32, 'Break rod 13 inch', '120', 700.00, 710.00, 5, 18, '2024-04-08 09:49:23'),
(33, 'Break rod 33 inch', '22', 510.00, 524.00, 5, 0, '2024-04-08 09:50:13'),
(34, 'Key set', '5', 300.00, 310.00, 5, 20, '2024-04-09 08:10:01'),
(35, 'front indicator', '9', 800.00, 805.00, 5, 21, '2024-04-09 08:11:17'),
(36, 'Gromet small', '88', 5.00, 6.00, 5, 22, '2024-04-09 08:13:25'),
(37, 'Gromet big', '97', 1500.00, 1550.00, 5, 23, '2024-04-09 08:14:20'),
(38, 'Digital meter', '5', 500.00, 550.00, 5, 24, '2024-04-09 08:15:47'),
(39, '3 W break indicator', '8', 700.00, 720.00, 5, 25, '2024-04-09 08:17:06'),
(40, 'Metal product', '25', 500.00, 510.00, 5, 26, '2024-04-09 08:18:59'),
(41, 'Buggy front light', '3', 400.00, 420.00, 5, 27, '2024-04-09 08:19:53'),
(42, 'Emergency switch bok', '5', 950.00, 960.00, 5, 28, '2024-04-09 08:20:49'),
(43, 'Wiper blade with arm', '32', 400.00, 430.00, 5, 29, '2024-04-09 08:22:56'),
(44, 'Balancing rod', '15', 150.00, 165.00, 5, 30, '2024-04-09 08:23:40'),
(45, 'Differential oil', '35', 750.00, 785.00, 5, 31, '2024-04-09 08:25:11'),
(46, 'Buggy mirror ', '59', 100.00, 112.00, 5, 32, '2024-04-09 08:26:09'),
(47, 'Passenger mirror', '2', 320.00, 350.00, 5, 33, '2024-04-09 08:26:51'),
(48, 'Camera set', '4', 499.00, 514.00, 5, 34, '2024-04-09 08:27:44'),
(49, 'Meter cable 42 inch', '5', 150.00, 155.00, 5, 35, '2024-04-09 08:28:22'),
(50, 'Roof rubber binding', '3', 300.00, 320.00, 5, 36, '2024-04-09 08:29:03'),
(51, 'Leaf spring', '8', 1300.00, 1350.00, 5, 37, '2024-04-09 08:29:54'),
(52, 'Handel T', '13', 750.00, 770.00, 5, 38, '2024-04-09 08:33:08'),
(53, 'Spray paint', '11', 320.00, 327.00, 5, 39, '2024-04-09 08:34:03'),
(54, 'powder coating powder( red ) per kg', '40', 250.00, 255.00, 5, 40, '2024-04-09 08:36:09'),
(55, 'powder coating powder( green ) per kg', '40', 180.00, 180.00, 5, 41, '2024-04-09 08:37:55'),
(56, 'powder coating powder( black ) per kg', '40', 350.00, 350.00, 5, 42, '2024-04-09 08:38:39'),
(57, 'u clamp square plate', '54', 34.00, 36.00, 5, 43, '2024-04-09 08:40:09'),
(58, 'u clamp', '247', 60.00, 62.00, 5, 44, '2024-04-09 08:40:44'),
(59, 'fork pipe', '50', 1200.00, 1210.00, 5, 45, '2024-04-09 08:41:18'),
(60, 'Front glass', '7', 1500.00, 1510.00, 5, 46, '2024-04-09 08:42:11'),
(61, 'Half root for loader', '5', 1500.00, 1510.00, 5, 47, '2024-04-09 08:43:02'),
(62, 'Leaf spring 18', '5', 800.00, 810.00, 5, 48, '2024-04-09 08:45:04'),
(63, 'Leaf spring 19', '1', 800.00, 1.00, 5, 49, '2024-04-09 08:45:27'),
(64, 'Type 3 wheeler', '7', 1300.00, 1310.00, 5, 50, '2024-04-09 08:50:01'),
(65, 'Tyre(Buggy)', '4', 1500.00, 1510.00, 5, 51, '2024-04-09 08:50:26'),
(66, 'Horn', '10', 120.00, 120.00, 5, 52, '2024-04-09 08:51:01'),
(67, 'Front axle rod 3 wheeler', '15', 300.00, 300.00, 5, 53, '2024-04-09 08:52:02'),
(68, 'Battery charger', '-1', 3000.00, 3000.00, 5, 54, '2024-04-09 08:53:02'),
(69, 'Seat Bundels 2', '2', 1100.00, 1100.00, 5, 55, '2024-04-09 08:54:00'),
(70, 'Rexin cloth', '3', 500.00, 500.00, 5, 56, '2024-04-09 08:54:50'),
(71, 'Rear break liver', '7', 150.00, 160.00, 5, 57, '2024-04-09 08:55:43'),
(72, 'Chassis 4w ', '2', 4000.00, 4000.00, 5, 58, '2024-04-09 08:57:18'),
(73, 'Chassis 3w passenger', '3', 30000.00, 30000.00, 5, 59, '2024-04-09 08:58:22'),
(74, 'Front glass support frame', '10', 1500.00, 1500.00, 5, 60, '2024-04-09 08:59:56'),
(75, 'Final product 1', '-9', 180000.00, 180000.00, 9, 61, '2024-04-09 09:08:59');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `qty`, `price`, `date`) VALUES
(9, 23, 5, 150.00, '2024-05-15'),
(10, 75, 10, 1800000.00, '2024-05-15'),
(11, 22, 2, 1080.00, '2024-05-15'),
(12, 15, 2, 13800.00, '2024-05-15'),
(13, 68, 3, 9000.00, '2024-05-15'),
(14, 26, 1, 7350.00, '2024-05-15'),
(15, 39, 1, 720.00, '2024-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `image`, `status`, `last_login`) VALUES
(1, 'Srivalli', 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1, 'o70ng9ku1.jpeg', 1, '2024-05-17 07:18:14'),
(2, 'Harini devi', 'Harini', 'bfce0e8299132a377383eeb73bbe637a9a7ac9c4', 2, 'no_image.png', 1, '2024-05-15 14:41:04'),
(3, 'Balagam vasu', 'vasu', 'fdfdb2cd979b7b8f17791cc46d595851145a3915', 2, 'no_image.png', 1, '2024-05-15 14:49:34'),
(4, 'Mahesh babu', 'mahesh', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 3, 'no_image.png', 1, NULL),
(5, 'Gani babu', 'gani', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 3, 'no_image.png', 1, '2021-04-04 19:54:29'),
(6, 'Srujana', 'srujana', '12dea96fec20593566ab75692c9949596833adc9', 3, 'no_image.jpg', 1, NULL),
(7, 'Prince snehith', 'snehith', '12dea96fec20593566ab75692c9949596833adc9', 3, 'no_image.jpg', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Admin', 1, 1),
(2, 'Manager', 2, 1),
(3, 'Customer', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_level` (`user_level`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_level` (`group_level`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `SK` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_level`) REFERENCES `user_groups` (`group_level`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
