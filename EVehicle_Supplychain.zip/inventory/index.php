<?php
  ob_start();
  require_once('includes/load.php');
  if($session->isUserLoggedIn(true)) { redirect('home.php', false);}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      font-weight: 400;
      overflow-x: hidden;
      overflow-y: auto;
      position: relative;
      height: 100%;
      width: 100%;
    }

    img.background-image {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 150%;
      object-fit: cover;
      z-index: -1;
    }

    .login-page {
      width: 350px;
      margin: 5% auto;
      padding: 20px;
      background-color: rgba(249, 249, 249, 0.9); /* Added transparency */
      border: 1px solid #f2f2f2;
    }

    .login-page .text-center {
      margin-bottom: 10px;
    }

    .form-control {
      color: #646464;
      border: 1px solid #e6e6e6;
      border-radius: 3px;
    }

    .btn {
      border-radius: 3px;
      transition: all 300ms ease-in-out;
    }

    .btn-primary {
      color: #fff;
      background-color: #51aded;
      border-color: #3d8fd8;
    }

    .btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active {
      background-color: #3175b8;
      border-color: #3d8fd8;
    }
  </style>
</head>
<body>
  <?php include_once('layouts/header.php'); ?>
  <img class="background-image" src="images.jpg" alt="Background Image">
  <div class="login-page">
    <div class="text-center">
      <h1>Login Panel</h1>
      <h4>Supplychain Management System</h4>
    </div>
    <?php echo display_msg($msg); ?>
    <form method="post" action="auth.php" class="clearfix">
      <div class="form-group">
        <label for="username" class="control-label">Username</label>
        <input type="name" class="form-control" name="username" placeholder="Username">
      </div>
      <div class="form-group">
        <label for="Password" class="control-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password">
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary" style="border-radius:0%">Login</button> <!-- Changed to btn-primary for blue color -->
      </div>
    </form>
  </div>
  <?php include_once('layouts/footer.php'); ?>
</body>
</html>
