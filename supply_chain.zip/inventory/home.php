<?php
  $page_title = 'Home Page';
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<!-- Adding CSS for animations and styling -->
<style>
  body {
    background: linear-gradient(to right, #ff7e5f, #feb47b);
    font-family: 'Arial', sans-serif;
  }
  .jumbotron {
    background: rgba(255, 255, 255, 0.8);
    padding: 2em;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
    
  }
  .jumbotron:hover {
    transform: scale(1.05);
  }
  h1 {
    font-size: 3em;
    color: #333;
    animation: fadeIn 2s ease-in-out;
  }
  p {
    font-size: 1.5em;
    color: #555;
    animation: fadeIn 3s ease-in-out;
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  .button-container {
    margin-top: 20px;
  }
  .btn-custom {
    background-color: #ff7e5f;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 1.2em;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out, transform 0.3s ease-in-out;
  }
  .btn-custom:hover {
    background-color: #feb47b;
    transform: scale(1.1);
  }
</style>

<!-- Adding JavaScript for interactive elements -->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const btn = document.querySelector('.btn-custom');
    btn.addEventListener('click', function() {
      window.location.href = 'http://localhost/Inventory/admin.php'; // Redirect to dashboard.php or any page you want
    });
  });
</script>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
        <h1>Welcome User <hr> Supplychain Management System</h1>
        <p>Browse around to find out the pages that you can access!</p>
        <div class="button-container">
          <button class="btn-custom">Get Started</button>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
